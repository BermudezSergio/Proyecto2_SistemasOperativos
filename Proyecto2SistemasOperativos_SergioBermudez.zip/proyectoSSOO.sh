rm *primos.txt 
./encuentraprimos 4 0
sort primos.txt > sortedprimos.txt
